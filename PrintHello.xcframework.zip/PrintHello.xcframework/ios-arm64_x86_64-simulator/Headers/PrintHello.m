#import "PrintHello.h"

@implementation PrintHello

+ (void)print {
    NSLog(@"Hello from static library!");
}

@end
