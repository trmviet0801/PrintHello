#import <Foundation/Foundation.h>

@interface PrintHello : NSObject

+ (void)print;

@end
